/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PoadCast.cpp
 * Author: 2017101996
 * 
 * Created on 15 de Outubro de 2019, 17:07
 */

#include "Poadcast.hpp"

Poadcast::Poadcast(){
    
}
    
Poadcast::Poadcast(string nome, Genero* gen,int qtdTemp) : Midia(nome, codigo, genero){
    this->qtdTemporadas=qtdTemp;
}

void Poadcast::imprimeInfoProduto(){
    
}

Poadcast::~Poadcast(){
    
}

